package org.nagarro.java.springmvc.ass4.service;

import org.springframework.stereotype.Service;

@Service
public class HrService {

	private static final String USER1 = "Rohan123";
	private static final String USER2 = "Vishal123";
	private static final String Pass1 = "@123456";
	private static final String Pass2 = "@123456";

	public boolean checkHrDetails(String uname, String pass) {
		System.out.println(uname);
		System.out.println(pass);
		boolean flag = false;
		if (uname.equals(USER1) && pass.equals(Pass1)) {
			flag = true;
		}

		else if (uname.equals(USER2) && pass.equals(Pass2)) {
			flag = true;
		}
		return flag;
	}
}
