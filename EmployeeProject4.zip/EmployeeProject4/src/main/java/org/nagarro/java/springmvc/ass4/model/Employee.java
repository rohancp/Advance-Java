package org.nagarro.java.springmvc.ass4.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "emp_details")
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int empCode;
	private String empName;
	private String empLocation;
	private String empEmail;
	private String empDOB;

	public int getEmpCode() {
		return empCode;
	}

	public void setEmpCode(int empCode) {
		this.empCode = empCode;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpLocation() {
		return empLocation;
	}

	public void setEmpLocation(String empLocation) {
		this.empLocation = empLocation;
	}

	public String getEmpEmail() {
		return empEmail;
	}

	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}

	public String getEmpDOB() {
		return empDOB;
	}

	public void setEmpDOB(String empDOB) {
		this.empDOB = empDOB;
	}

	@Override
	public String toString() {
		return "Employee [empCode=" + empCode + ", empName=" + empName + ", empLocation=" + empLocation + ", empEmail="
				+ empEmail + ", empDOB=" + empDOB + "]";
	}

	public Employee(int empCode, String empName, String empLocation, String empEmail, String empDOB) {
		super();
		this.empCode = empCode;
		this.empName = empName;
		this.empLocation = empLocation;
		this.empEmail = empEmail;
		this.empDOB = empDOB;
	}

	public Employee() {
		super();
	}

}
