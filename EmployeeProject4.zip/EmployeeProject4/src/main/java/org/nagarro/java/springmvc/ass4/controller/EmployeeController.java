package org.nagarro.java.springmvc.ass4.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.nagarro.java.springmvc.ass4.model.EmployeeSession;
import org.nagarro.java.springmvc.ass4.service.EmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class EmployeeController {

	@Autowired
	private EmpService empService;

	@RequestMapping(path = "/addEmp", method = RequestMethod.POST)
	public String addEmp(HttpServletRequest request) {

		if(!EmployeeSession.sessionExist(request))
			return "redirect:/login";
		return "addemp";
	}

	@RequestMapping(path = "/createEmployee", method = RequestMethod.POST)
	public String createEmp(HttpServletRequest request, Model model) {
		if(!EmployeeSession.sessionExist(request))
			return "redirect:/login";
		String empName = request.getParameter("empname");
		String empLoc = request.getParameter("emploc");
		String empEmail = request.getParameter("empemail");
		String empDob = request.getParameter("empdob");
		int id = this.empService.createEmployees(empName, empLoc, empEmail, empDob);
		model.addAttribute("id", id);
		return "success";
	}

	@RequestMapping(path = "/edit", method = RequestMethod.POST)
	public String editEmployeeDetails(HttpServletRequest request, Model model) {
		if(!EmployeeSession.sessionExist(request))
			return "redirect:/login";
		String empcode = request.getParameter("emc");
		model.addAttribute("empCode", empcode);
		System.out.println("Edit handler!!..");
		return "edit";
	}

	@RequestMapping(path = "/save", method = RequestMethod.POST)
	public String saveEmployee(HttpServletRequest request, Model model) {
		if(!EmployeeSession.sessionExist(request))
			return "redirect:/login";
		int empCode = Integer.parseInt(request.getParameter("empCode"));
		String empName = request.getParameter("empName");
		String empLoc = request.getParameter("empLoc");
		String empEmail = request.getParameter("empEmail");
		String empDob = request.getParameter("empDob");
		if (empName.isEmpty() || empLoc.isEmpty() || empEmail.isEmpty() || empDob.isEmpty()) {
			model.addAttribute("empCode", empCode);
			return "edit";
		}
		this.empService.updateEmp(empCode, empName, empLoc, empEmail, empDob);
		return "savesuccess";
	}

	@RequestMapping(path = "/logout", method = RequestMethod.POST)
	public String logout(HttpServletRequest request) {
		HttpSession session = request.getSession();
		System.out.println(session.getAttribute("UNAME"));
		session.invalidate();
		System.out.println("logout handler!!..");
		return "redirect:/login";
	}
}
