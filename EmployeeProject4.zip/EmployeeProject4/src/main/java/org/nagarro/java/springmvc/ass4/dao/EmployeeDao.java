package org.nagarro.java.springmvc.ass4.dao;

import java.util.List;

import org.nagarro.java.springmvc.ass4.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class EmployeeDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	// add New Employee.
	@Transactional
	public int addEmployee(Employee emp) {
		
		int i = (Integer)this.hibernateTemplate.save(emp);
		return i;
	}
	
	// Retrieve all employees
	public List<Employee> getEmployess(){
		List<Employee> emps = this.hibernateTemplate.loadAll(Employee.class);
		return emps;
	}
	
	// update Employee details.
	@Transactional
	public void updateEmployee(Employee emp) {
		this.hibernateTemplate.update(emp);
	}
}
