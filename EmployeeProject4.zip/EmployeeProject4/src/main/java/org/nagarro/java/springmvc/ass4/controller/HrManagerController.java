package org.nagarro.java.springmvc.ass4.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.nagarro.java.springmvc.ass4.model.Employee;
import org.nagarro.java.springmvc.ass4.model.EmployeeSession;
import org.nagarro.java.springmvc.ass4.service.EmpService;
import org.nagarro.java.springmvc.ass4.service.HrService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HrManagerController {

	@Autowired
	private HrService hrService;

	@Autowired
	private EmpService empService;

	private boolean sessionFlag = false;
	private boolean check = false;

	@RequestMapping(path = "/login")
	public String loginPage(Model model) {

		sessionFlag = false;
		System.out.println("login handler");
		if (check) {
			check = false;
			model.addAttribute("error", "Invalide Username or Password!!..");
		}
		return "index";
	}

	@RequestMapping(path = "/checkhrdetails", method = RequestMethod.POST)
	public String checkHrDetails(@RequestParam("Uname") String uname, @RequestParam("Pass") String pass,
			HttpServletRequest request) {
		System.out.println("hr details handler..");
		if (this.hrService.checkHrDetails(uname, pass)) {
			HttpSession session = request.getSession();
			session.setAttribute("UNAME", uname);
			return "redirect:/checkhr";
		}
		check = true;
		return "redirect:/login";
	}

	@RequestMapping(path = "/checkhr")
	public String checkHr(Model model, HttpServletRequest request) {

		System.out.println("Check Hr handler");
		if (EmployeeSession.sessionExist(request)) {
			List<Employee> empls = this.empService.getAllEmployess();
			model.addAttribute("employees", empls);
			sessionFlag = true;
			return "showemployee";
		}

		return "redirect:/login";

	}
}
