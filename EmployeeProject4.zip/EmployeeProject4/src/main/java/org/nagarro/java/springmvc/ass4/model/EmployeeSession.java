package org.nagarro.java.springmvc.ass4.model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class EmployeeSession {

	
	public static  boolean sessionExist(HttpServletRequest request) {
		
		HttpSession ses = request.getSession();
		if(ses.getAttribute("UNAME") == null)
			return false;
		return true;
	}
}
