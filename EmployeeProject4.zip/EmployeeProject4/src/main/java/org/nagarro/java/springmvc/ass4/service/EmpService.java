package org.nagarro.java.springmvc.ass4.service;

import java.util.ArrayList;
import java.util.List;

import org.nagarro.java.springmvc.ass4.dao.EmployeeDao;
import org.nagarro.java.springmvc.ass4.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmpService {

	@Autowired
	private EmployeeDao empDao;

	public int createEmployees(String empName, String empLoc, String empEmail, String empDob) {

		Employee emp = new Employee();
		emp.setEmpName(empName);
		emp.setEmpLocation(empLoc);
		emp.setEmpEmail(empEmail);
		emp.setEmpDOB(empDob);
		int id = this.empDao.addEmployee(emp);
		System.out.println(id);
		return id;
	}

	public List<Employee> getAllEmployess() {

		return this.empDao.getEmployess();

	}

	public void updateEmp(int empCode, String empName, String empLoc, String empEmail, String empDob) {
			
		Employee emp = new Employee();
		emp.setEmpCode(empCode);
		emp.setEmpDOB(empDob);
		emp.setEmpEmail(empEmail);
		emp.setEmpLocation(empLoc);
		emp.setEmpName(empName);
		this.empDao.updateEmployee(emp);
	}
}
