package org.nagarro.java.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.persistence.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.nagarro.java.entities.Fields;
import org.nagarro.java.helper.FactoryProvider;

public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		SessionFactory factory = FactoryProvider.getFactory();
		Session session = factory.openSession();
		String query = "from Fields as f where f.username =: u and f.password =: f";
		Query q = session.createQuery(query);
		q.setParameter("u", request.getParameter("userName"));
		q.setParameter("f", request.getParameter("password"));
		@SuppressWarnings("unchecked")
		List<Fields> list = q.getResultList();
		PrintWriter out = response.getWriter();
		if (list.size() == 0) {
			response.setContentType("text/html");
			out.println("Invalid username or Password!!..");
			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.include(request, response);
		} else {
			session.close();
			System.out.println("showimages");
			RequestDispatcher rd = request.getRequestDispatcher("ShowImages.jsp");
			rd.forward(request, response);

		}
	}
}