package org.nagarro.java.filters;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.nagarro.java.entities.Fields;
import org.nagarro.java.entities.UserImages;
import org.nagarro.java.helper.FactoryProvider;

public class AddEnteries implements Filter {
	private static final long MEGABYTE = 1024L * 1024L;
	private static boolean flag = false;
	private static final DecimalFormat df2 = new DecimalFormat("#.##");

	public void destroy() {

	}

	private static double getImageSize(String p) throws IOException {
		Path path = Paths.get(p);
		long result;
		result = Files.size(path);
		double r = (result / (double) MEGABYTE);
		r = Double.parseDouble(df2.format(r));
		return r;
	}

	private static byte[] getImage2(String p) throws IOException {
		FileInputStream fis = new FileInputStream(p);
		byte[] data = new byte[fis.available()];
		fis.read(data);
		return data;
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		if (!flag) {
			flag = true;
			UserImages img1 = new UserImages();
			img1.setId(1);
			img1.setImageName("Python for Beginners");
			img1.setImageSize(getImageSize("C:\\Users\\rohan\\Desktop\\Images\\41+l48O6TbL.jpg"));
			img1.setImage(getImage2("C:\\Users\\rohan\\Desktop\\Images\\41+l48O6TbL.jpg"));

			UserImages img2 = new UserImages();
			img2.setId(2);
			img2.setImageName("Javascript");
			img2.setImageSize(getImageSize("C:\\Users\\rohan\\Desktop\\Images\\71WzJARrAwL.jpg"));
			img2.setImage(getImage2("C:\\Users\\rohan\\Desktop\\Images\\71WzJARrAwL.jpg"));

			UserImages img3 = new UserImages();
			img3.setId(3);
			img3.setImageName("Java");
			img3.setImageSize(getImageSize("C:\\Users\\rohan\\Desktop\\Images\\9789389520910.jpg"));
			img3.setImage(getImage2("C:\\Users\\rohan\\Desktop\\Images\\9789389520910.jpg"));

			UserImages img4 = new UserImages();
			img4.setId(4);
			img4.setImageName("Javascript and jQquery");
			img4.setImageSize(getImageSize("C:\\Users\\rohan\\Desktop\\Images\\11318858.jpg"));
			img4.setImage(getImage2("C:\\Users\\rohan\\Desktop\\Images\\11318858.jpg"));

			List<UserImages> list1 = new ArrayList<UserImages>();
			list1.add(img1);
			list1.add(img2);
			List<UserImages> list2 = new ArrayList<UserImages>();
			list2.add(img3);
			list2.add(img4);

			Fields user1 = new Fields();
			user1.setUsername("rohan_rana45");
			user1.setPassword("rana_jhk");
			user1.setUserImages(list1);

			Fields user2 = new Fields();
			user2.setUsername("sumit_sara");
			user2.setPassword("sumit@901");
			user2.setUserImages(list2);
			SessionFactory factory = FactoryProvider.getFactory();
			Session session = factory.openSession();
			Transaction tx = null;
			try {
				tx = session.beginTransaction();
				session.save(user1);
				session.save(user2);
				session.save(img1);
				session.save(img2);
				session.save(img3);
				session.save(img4);
				tx.commit();
				chain.doFilter(request, response);
			} catch (Exception e) {
				if (tx != null) {
					tx.rollback();
				}
				e.printStackTrace();
			} finally {
				session.close();
			}
		} else {
			chain.doFilter(request, response);
		}
	}

	public void init(FilterConfig fConfig) throws ServletException {

	}

}
