package org.nagarro.java.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.nagarro.java.helper.FactoryProvider;

public class Delete extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		SessionFactory factory = FactoryProvider.getFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		int ID = Integer.parseInt(request.getParameter("Id"));
		String Query = "delete from UserImages as um where um.id =: v";
		Query q = session.createQuery(Query);
		q.setParameter("v", ID);
		q.executeUpdate();
		tx.commit();
		System.out.println("Successfull Deleted!!..");
		out.println("Successfull Deleted!!..");
		session.close();
	}

}
