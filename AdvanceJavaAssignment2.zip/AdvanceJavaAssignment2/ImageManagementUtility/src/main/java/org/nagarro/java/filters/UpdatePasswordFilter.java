package org.nagarro.java.filters;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.nagarro.java.entities.Fields;
import org.nagarro.java.helper.FactoryProvider;

public class UpdatePasswordFilter implements Filter {

	public void destroy() {

	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		String uname = request.getParameter("username");
		String passwrd = request.getParameter("password");
		String confpass = request.getParameter("confirmpassword");
		PrintWriter out = response.getWriter();
		RequestDispatcher rd = request.getRequestDispatcher("ForgotPassword.jsp");
		if ((passwrd.length() < 6) || (confpass.length() < 6)) {
			out.println("Password length should be minimum 6..");

			rd.include(request, response);
		} else if (!(passwrd.equals(confpass))) {
			out.println("Password and ConfirmPassword should be same..");
			rd.include(request, response);
		} else {
			SessionFactory factory = FactoryProvider.getFactory();
			Session session = factory.openSession();
			Fields f = (Fields) session.get(Fields.class, uname);
			if (f == null) {
				out.println("Username doesn't exist!..");
				rd.include(request, response);
			} else {
				chain.doFilter(request, response);
			}

		}

	}

	public void init(FilterConfig fConfig) throws ServletException {

	}

}
