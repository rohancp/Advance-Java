package org.nagarro.java.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.nagarro.java.entities.Fields;
import org.nagarro.java.entities.UserImages;
import org.nagarro.java.helper.FactoryProvider;

public class UserImageDAO {
	
	@SuppressWarnings("unchecked")
	public static List<UserImages> getData(String usern, String passw){
		System.out.println("daouimages");
		List<UserImages> list = null;
		SessionFactory factory = FactoryProvider.getFactory();
		Session session = factory.openSession();
		String query = "from Fields as f where f.username =: u and f.password =: f";
		Query q = session.createQuery(query);
		q.setParameter("u", usern);
		q.setParameter("f", passw);
		List<Fields> f = q.getResultList();
		for(Fields ff : f) {
			System.out.println(ff.getUsername());
			System.out.println(ff.getPassword());
		}
		list = f.get(0).getUserImages();
		session.close();
		return list;
	}
}
