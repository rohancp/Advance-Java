package org.nagarro.java.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.nagarro.java.dao.EditImageDAO;

public class EditImageData extends HttpServlet {
	private static final long MEGABYTE = 1024L * 1024L;
	private static final DecimalFormat df2 = new DecimalFormat("#.##");

	private static double getImageSize(String p) throws IOException {
		Path path = Paths.get(p);
		long result;
		result = Files.size(path);
		double r = (result / (double) MEGABYTE);
		r = Double.parseDouble(df2.format(r));
		return r;
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			PrintWriter out = response.getWriter();
			RequestDispatcher rd = request.getRequestDispatcher("Edit.jsp");
			System.out.println("EditImageData");
			String file = request.getParameter("myfile");
			String bookName = request.getParameter("bookName");
			int id = Integer.parseInt(request.getParameter("Id"));
			double imageSize = getImageSize(file);
			if (imageSize <= 1.0) {
				EditImageDAO.updateImageDetails(id, imageSize, bookName, file);
				out.println("Successfully Update!!..");
				rd.include(request, response);
			} else {
				out.println("Image Size Shoulde be Maximum 1 MB");
				rd.include(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}