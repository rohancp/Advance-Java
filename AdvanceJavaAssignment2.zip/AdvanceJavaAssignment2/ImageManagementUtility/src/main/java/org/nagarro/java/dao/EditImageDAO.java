package org.nagarro.java.dao;

import java.io.FileInputStream;
import java.io.IOException;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.nagarro.java.helper.FactoryProvider;

public class EditImageDAO {

	private static byte[] getImage2(String p) throws IOException {
		FileInputStream fis = new FileInputStream(p);
		byte[] data = new byte[fis.available()];
		fis.read(data);
		return data;
	}

	public static void updateImageDetails(int id, double imgSize, String bookName, String file) {
		try {
			// image converted into byte array..
			byte[] image = getImage2(file);
			SessionFactory factory = FactoryProvider.getFactory();
			Session session = factory.openSession();
			Transaction tx = session.beginTransaction();
			String query = "update UserImages set imageSize =: ims, imageName =: imn, image =: im where id =: i";
			Query q = session.createQuery(query);
			q.setParameter("ims", imgSize);
			q.setParameter("imn", bookName);
			q.setParameter("im", image);
			q.setParameter("i", id);
			q.executeUpdate();
			System.out.println("Successfull Update..");
			tx.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
