package org.nagarro.springrest.services;

import java.util.List;

import org.nagarro.springrest.dao.EmployeeDao;
import org.nagarro.springrest.model.Employee;
import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	private EmployeeDao employeeDao;

	@Override
	public List<Employee> getEmployees() {
		return this.employeeDao.findAll();

	}

	@Override
	public Employee getEmployee(long id) {
		return this.employeeDao.getOne(id);
	}

	@Override
	public Employee addEmployee(Employee employee) {
		this.employeeDao.save(employee);
		return employee;
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		this.employeeDao.save(employee);
		return employee;
	}

	@Override
	public void deleteEmployee(long parseLong) {
		Employee entity = this.employeeDao.getOne(parseLong);
		this.employeeDao.delete(entity);
	}

}
