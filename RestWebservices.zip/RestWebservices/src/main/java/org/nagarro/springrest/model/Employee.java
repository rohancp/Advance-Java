package org.nagarro.springrest.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "employee_details")
public class Employee {

	@Id
	private long empId;
	private String empName;
	private String empLoc;
	private String empEmail;
	private String empDob;
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empLoc=" + empLoc + ", empEmail=" + empEmail
				+ ", empDob=" + empDob + "]";
	}
	public long getEmpId() {
		return empId;
	}
	public void setEmpId(long empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpLoc() {
		return empLoc;
	}
	public void setEmpLoc(String empLoc) {
		this.empLoc = empLoc;
	}
	public String getEmpEmail() {
		return empEmail;
	}
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	public String getEmpDob() {
		return empDob;
	}
	public void setEmpDob(String empDob) {
		this.empDob = empDob;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(long empId, String empName, String empLoc, String empEmail, String empDob) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empLoc = empLoc;
		this.empEmail = empEmail;
		this.empDob = empDob;
	}
	 
}
