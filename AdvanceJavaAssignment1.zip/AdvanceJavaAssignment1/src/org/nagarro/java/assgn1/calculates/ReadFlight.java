package org.nagarro.java.assgn1.calculates;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;

public class ReadFlight implements Runnable {
	private String csv;
	private static String deploc;
	private static String arrvloc;
	private static String flightdate;
	private static String flightclass;
	private static String outp;
	private static final String SEAT_AVAILABLE = "Y";
	private static final String SKIP_ROW = "FLIGHT_NO";
	private static LinkedList<String> avalibleflights = new LinkedList<String>();

	public ReadFlight(String csv) {
		this.csv = csv;
	}

	public static void intialized(String dl, String al, String fd, String fc, String op) {
		deploc = dl;
		arrvloc = al;
		flightdate = fd;
		flightclass = fc;
		outp = op;
	}

	public static void printSomething() {
		System.out.println(deploc);
		System.out.println(arrvloc);
		System.out.println(flightdate);
		System.out.println(flightclass);
		System.out.println(outp);
	}

	public static LinkedList<String> getAvailableFlights() {
		return avalibleflights;
	}

	// this function checks how many available flights.

	public synchronized void availableFlight() throws IOException, ParseException {
		String l = null;
		BufferedReader reader = Files.newBufferedReader(Paths.get(csv));
		while ((l = reader.readLine()) != null) {
			synchronized (this) {
				String flightdetails[] = l.split("\\|");
				if (!SKIP_ROW.equalsIgnoreCase(flightdetails[0])) {
					String tardeploc = flightdetails[1];
					String tararrvloc = flightdetails[2];
					String seatavailable = flightdetails[7];
					String tarclass = flightdetails[8];
					String tardate = flightdetails[3];
					SimpleDateFormat sdfo = new SimpleDateFormat("dd-MM-yyyy");
					Date validtill = sdfo.parse(tardate);
					Date fdate = sdfo.parse(flightdate);
					if ((deploc.equals(tardeploc)) && (arrvloc.equals(tararrvloc))
							&& (seatavailable.equals(SEAT_AVAILABLE)) && (tarclass.contains(flightclass))
							&& (validtill.compareTo(fdate) >= 0)) {
						avalibleflights.add(l);
					}

				}
			}
		}
	}

	@Override
	public void run() {

		try {
			availableFlight();

		} catch (IOException e) {
			System.out.println(e);
		} catch (ParseException e) {
			System.out.println(e);
		}

	}
}
