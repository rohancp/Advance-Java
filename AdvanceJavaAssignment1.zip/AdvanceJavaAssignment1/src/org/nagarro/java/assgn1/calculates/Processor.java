package org.nagarro.java.assgn1.calculates;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.LinkedList;
import java.util.Vector;

import org.nagarro.java.assgn1.flight.Flight;

public class Processor {
	private static final String BUSSINESS_FLIGHT_CLASS = "B";
//	private static final String OUTPUT_PREFRENCES = "2";
	// now we shows all the flights currently which is Available..

	private static void showAvailableFlights(LinkedList<String> flights, String outpref, String flightclass) {
		ArrayList<Flight> allflights = new ArrayList<>();
		try {
			for (String currentflight : flights) {
				String flightrow[] = currentflight.split("\\|");
				double fare = Double.parseDouble(flightrow[6]);
				if (flightclass.equals(BUSSINESS_FLIGHT_CLASS)) {
					fare += (fare * 0.40);
				}
				Flight obj = new Flight();
				obj.setFlightNumber(flightrow[0]);
				obj.setDepartureLocation(flightrow[1]);
				obj.setArrivalLocation(flightrow[2]);
				obj.setFlightTime(flightrow[4]);
				obj.setFlightDuration(flightrow[5]);
				obj.setFlightFare((int) fare);
				allflights.add(obj);
			}
			// sorted by fare..
			allflights.sort((Flight sf1, Flight sf2) -> sf1.getFlightFare() - sf2.getFlightFare());
			System.out.println("FLIGHT_NO  DEP_LOC  ARR_LOC  FLIGHT_TIME  FLIGHT_DUR  FLIGHT_FARE");
			System.out.println("-------------------------------------------------------------------");
			allflights.forEach(f -> System.out.println(f));

			// sorted by flight duration
			allflights.sort(
					(Flight sf1, Flight sf2) -> sf1.getFlightDuration().compareTo(sf2.getFlightDuration()));
			System.out.println("FLIGHT_NO  DEP_LOC  ARR_LOC  FLIGHT_TIME  FLIGHT_DUR  FLIGHT_FARE");
			System.out.println("-------------------------------------------------------------------");
			allflights.forEach(f -> System.out.println(f));
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String deploc = br.readLine();
		String arrvloc = br.readLine();
		String flightdate = br.readLine();
		String flightclass = br.readLine();
		String outpref = br.readLine();
		ReadFlight.intialized(deploc, arrvloc, flightdate, flightclass, outpref);
		Vector<Thread> threads = new Vector<Thread>();
		int csvindex = 0;
//		String line = null;
		try {
			File directoryPath = new File("C:\\Users\\rohan\\Desktop\\JAVA PLANS\\advance java\\Assignment Links");
			File fileslist[] = directoryPath.listFiles();
			for(File file : fileslist) {
				ReadFlight f = new ReadFlight(file.getAbsolutePath());
				threads.add(new Thread(f));
				threads.get(csvindex).start();
				csvindex++;
			}
//			BufferedReader reader = Files.newBufferedReader(
//					Paths.get("C:\\Users\\rohan\\Desktop\\JAVA PLANS\\advance java\\Assign1\\Csvfiles.txt"));
//			while ((line = reader.readLine()) != null) {
//				ReadFlight f = new ReadFlight(line);
//				threads.add(new Thread(f));
//				threads.get(csvindex).start();
//				csvindex++;
//			}
			threads.forEach(thread -> {
				try {
					thread.join();
				} catch (InterruptedException e) {
					System.out.println(e);
				}
			});

			LinkedList<String> availableflights = ReadFlight.getAvailableFlights();
			if (availableflights.size() == 0)
				throw new EmptyStackException();
			System.out.println(availableflights.size());
			// availableflights.forEach(d->System.out.println(d));
			showAvailableFlights(availableflights, outpref, flightclass);
		} catch (EmptyStackException e) {
			System.out.println("Sorry, There is no available flights of these root!!..");
		}
	}
}
