package org.nagarro.java.assgn1.flight;

public class Flight {

	private String flightNumber;
	private String departureLocation;
	private String arrivalLocation;
	private String flightTime;
	private String flightDuration;
	private int flightFare;

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getDepartureLocation() {
		return departureLocation;
	}

	public void setDepartureLocation(String departureLocation) {
		this.departureLocation = departureLocation;
	}

	public String getArrivalLocation() {
		return arrivalLocation;
	}

	public void setArrivalLocation(String arrivalLocation) {
		this.arrivalLocation = arrivalLocation;
	}

	public String getFlightTime() {
		return flightTime;
	}

	public void setFlightTime(String flightTime) {
		this.flightTime = flightTime;
	}

	public String getFlightDuration() {
		return flightDuration;
	}

	public void setFlightDuration(String flightDuration) {
		this.flightDuration = flightDuration;
	}

	@Override
	public String toString() {
		return String.format("%-10s %-8s %-8s %-12s %-11s %-8s", flightNumber, departureLocation, arrivalLocation,
				flightTime, flightDuration, flightFare);
	}

	public int getFlightFare() {
		return flightFare;
	}

	public void setFlightFare(int flightFare) {
		this.flightFare = flightFare;
	}

}
