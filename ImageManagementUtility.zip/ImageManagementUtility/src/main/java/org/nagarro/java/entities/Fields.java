package org.nagarro.java.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "userfield")
public class Fields {

	@Id
	@Column(name = "username", length = 50)

	private String username;
	@Column(name = "password")
	private String password;

	@OneToMany
	private List<UserImages> userImages;

	public Fields(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}

	public Fields() {
		super();
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public List<UserImages> getUserImages() {
		return userImages;
	}

	public void setUserImages(List<UserImages> userImages) {
		this.userImages = userImages;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
