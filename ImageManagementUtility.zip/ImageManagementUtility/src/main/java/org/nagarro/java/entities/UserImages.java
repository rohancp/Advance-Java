package org.nagarro.java.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "userimages")
public class UserImages {

	@Id
	private int id;
	private double imageSize;
	private String imageName;
	@Lob
	private byte[] image;

	public UserImages() {
		super();
	}

	public UserImages(int id, double imageSize, String imageName, byte[] image) {
		super();
		this.id = id;
		this.imageSize = imageSize;
		this.imageName = imageName;
		this.image = image;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getImageSize() {
		return imageSize;
	}

	public void setImageSize(double imageSize) {
		this.imageSize = imageSize;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

}
