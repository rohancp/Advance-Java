package org.nagarro.java.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.persistence.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.nagarro.java.helper.FactoryProvider;

public class UpdatePasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String uname = request.getParameter("username");
		String passwrd = request.getParameter("password");
		SessionFactory factory = FactoryProvider.getFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		String query = "update Fields set password =: newpassword where username =: u";
		Query q = session.createQuery(query);
		q.setParameter("newpassword", passwrd);
		q.setParameter("u", uname);
		int r = q.executeUpdate();
		System.out.println("done "+r);
		PrintWriter out = response.getWriter();
		out.println("Updated Successfully!!...");
		RequestDispatcher rd = request.getRequestDispatcher("ForgotPassword.jsp");
		rd.include(request, response);
		tx.commit();
		session.close();
	}

}
