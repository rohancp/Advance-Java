package org.nagarro.java.springmvc.dao;

import java.util.List;

import org.nagarro.java.springmvc.model.Flight;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class FlightDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Transactional
	public int addFlight(Flight flight) {

		int id = (Integer) this.hibernateTemplate.save(flight);
		return id;
	}
	
	// get all flights	
	public List<Flight> getAllFlights() {
		List<Flight> flights = this.hibernateTemplate.loadAll(Flight.class);
		return flights;
	}
}
