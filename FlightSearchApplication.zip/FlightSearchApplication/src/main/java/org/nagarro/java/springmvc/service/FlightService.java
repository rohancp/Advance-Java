package org.nagarro.java.springmvc.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.nagarro.java.springmvc.dao.FlightDao;
import org.nagarro.java.springmvc.model.Flight;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FlightService {

	@Autowired
	private FlightDao flightDao;
	private static final String SKIP_ROW = "FLIGHT_NO";
	private static final String SEAT_AVAILABLE = "Y";

	// this method add flight entries into databases.
	public void addFlightEntries() {
		try {
			File directoryPath = new File("C:\\Users\\rohan\\Desktop\\JAVA PLANS\\advance java\\Assignment Links");
			File fileslist[] = directoryPath.listFiles();
			String l = null;
			for (File file : fileslist) {
				BufferedReader reader = Files.newBufferedReader(Paths.get(file.getAbsolutePath()));
				while ((l = reader.readLine()) != null) {
					String flightdetails[] = l.split("\\|");
					if (flightdetails[0].equals(SKIP_ROW))
						continue;
					Flight flight = new Flight();

					flight.setFlightNumber(flightdetails[0]);
					flight.setDepratureLocation(flightdetails[1]);
					flight.setArrivalLocation(flightdetails[2]);
					flight.setValidTill(flightdetails[3]);
					flight.setFlightTime(flightdetails[4].substring(0, 2) + ":" + flightdetails[4].substring(2));
					flight.setFlightDuration(flightdetails[5]);
					flight.setFare(Integer.parseInt(flightdetails[6]));
					flight.setSeatAvailability(flightdetails[7]);
					flight.setFlightClass(flightdetails[8]);
					int id = this.createFlight(flight);
					System.out.println(id);

				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public int createFlight(Flight flight) {

		int id = this.flightDao.addFlight(flight);
		return id;
	}

	// this method convert date into dateformat.(dd-MM-yyyy).
	public static String convertFlightDate(String flightDate) {

		String y = flightDate.substring(0, 4);
		String m = flightDate.substring(5, 7);
		String d = flightDate.substring(8);
		return d + "-" + m + "-" + y;
	}

	// this method return all available flights..
	public List<Flight> getAllAvailableFlights(String deploc, String arrvloc, String flightdate, String fclass,
			String outpref) throws ParseException {

		flightdate = convertFlightDate(flightdate);

		List<Flight> totalflights = this.flightDao.getAllFlights();
		List<Flight> actualflights = new ArrayList<Flight>();

		for (Flight flight : totalflights) {

			SimpleDateFormat sdfo = new SimpleDateFormat("dd-MM-yyyy");
			Date validtill = sdfo.parse(flight.getValidTill());

			// convert string to date format for comparing the date.
			Date fdate = sdfo.parse(flightdate);

			boolean departureLoc = flight.getDepratureLocation().equals(deploc);
			boolean arrivalLoc = flight.getArrivalLocation().equals(arrvloc);
			boolean seatAvail = flight.getSeatAvailability().equals(SEAT_AVAILABLE);
			boolean flightClass = flight.getFlightClass().contains(fclass);
			boolean flightDate = (validtill.compareTo(fdate) >= 0);

			if (departureLoc && arrivalLoc && seatAvail && flightClass && flightDate)
				actualflights.add(flight);
		}

		// 1 means flights will be sorted by fare.
		// 2 means flights will be sorted by fare as well as flight duration.
		if (Integer.parseInt(outpref) == 1) {
			actualflights.sort((Flight sf1, Flight sf2) -> sf1.getFare() - sf2.getFare());
		} else {
			Comparator<Flight> comparebyFareAndDuration = Comparator.comparing(Flight::getFare)
					.thenComparing(Flight::getFlightDuration);
			List<Flight> flights = actualflights.stream().sorted(comparebyFareAndDuration).collect(Collectors.toList());
			actualflights = flights;
		}

		return actualflights;
	}
}
