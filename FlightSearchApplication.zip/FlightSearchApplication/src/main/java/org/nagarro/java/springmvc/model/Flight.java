package org.nagarro.java.springmvc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "flight_details")
public class Flight {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int flightid;
	@Column(name = "FLIGHT_NO")
	private String flightNumber;
	@Column(name = "DEP_LOC")
	private String depratureLocation;
	@Column(name = "ARR_LOC")
	private String arrivalLocation;
	@Column(name = "VALID_TILL")
	private String validTill;
	@Column(name = "FLIGHT_TIME")
	private String flightTime;
	@Column(name = "FLIGHT_DUR")
	private String flightDuration;
	@Column(name = "FARE")
	private int fare;
	@Column(name = "SEAT_AVAILABILITY")
	private String seatAvailability;
	@Column(name = "CLASS")
	private String flightClass;

	public Flight() {
		super();
	}

	public Flight(int flightid, String flightNumber, String depratureLocation, String arrivalLocation, String validTill,
			String flightTime, String flightDuration, int  fare, String seatAvailability, String flightClass) {
		super();
		this.flightid = flightid;
		this.flightNumber = flightNumber;
		this.depratureLocation = depratureLocation;
		this.arrivalLocation = arrivalLocation;
		this.validTill = validTill;
		this.flightTime = flightTime;
		this.flightDuration = flightDuration;
		this.fare = fare;
		this.seatAvailability = seatAvailability;
		this.flightClass = flightClass;
	}

	public int getFlightid() {
		return flightid;
	}

	public void setFlightid(int flightid) {
		this.flightid = flightid;
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getDepratureLocation() {
		return depratureLocation;
	}

	public void setDepratureLocation(String depratureLocation) {
		this.depratureLocation = depratureLocation;
	}

	public String getArrivalLocation() {
		return arrivalLocation;
	}

	public void setArrivalLocation(String arrivalLocation) {
		this.arrivalLocation = arrivalLocation;
	}

	public String getValidTill() {
		return validTill;
	}

	public void setValidTill(String validTill) {
		this.validTill = validTill;
	}

	public String getFlightTime() {
		return flightTime;
	}

	public void setFlightTime(String flightTime) {
		this.flightTime = flightTime;
	}

	public String getFlightDuration() {
		return flightDuration;
	}

	public void setFlightDuration(String flightDuration) {
		this.flightDuration = flightDuration;
	}

	public int getFare() {
		return fare;
	}

	public void setFare(int fare) {
		this.fare = fare;
	}

	public String getSeatAvailability() {
		return seatAvailability;
	}

	public void setSeatAvailability(String seatAvailability) {
		this.seatAvailability = seatAvailability;
	}

	public String getFlightClass() {
		return flightClass;
	}

	public void setFlightClass(String flightClass) {
		this.flightClass = flightClass;
	}

}
