package org.nagarro.java.springmvc.controller;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.nagarro.java.springmvc.model.Flight;
import org.nagarro.java.springmvc.service.FlightService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class FlightController {

	@Autowired
	private FlightService flightService;
	private static boolean flag = false;

	// this is first login index.jsp page.
	@RequestMapping("/login")
	public String loginPage() {
		System.out.println("this is loginpage handler!!..");
		return "index";
	}

	@RequestMapping(path = "/checkuser", method = RequestMethod.POST)
	public String checkUser(HttpServletRequest request, Model model) throws IOException {

		if (!flag) {
			this.flightService.addFlightEntries();
			flag = true;
		}

		String uname = request.getParameter("userName");
		String upass = request.getParameter("userPassword");
		if (uname.equals("vishalRana123") && upass.equals("@123rana")) {
			return "flight";
		}
		return "redirect:/login";

	}

	@RequestMapping(path = "/searchflights", method = RequestMethod.POST)
	public String search(HttpServletRequest request, Model model) throws ParseException {
		String deploc = request.getParameter("deploc");
		String arrloc = request.getParameter("arrvloc");
		String ftdate = request.getParameter("flightdate");
		String fclass = request.getParameter("flightclass");
		String outpre = request.getParameter("outpref");
		List<Flight> flights = this.flightService.getAllAvailableFlights(deploc, arrloc, ftdate, fclass, outpre);
		System.out.println(flights.size());
		if (flights.size() == 0) {
			model.addAttribute("noflights", "No Available Flights of this root!!..");
		} else {
			model.addAttribute("noflights", "All Available Flights of this root!!..");
		}
		model.addAttribute("flights", flights);
		return "availableflights";
	}
}
